/*
 *  afangles.h
 *
 *  This is a dummy file, used to please the build system.  It is never
 *  included by the auto-fitter sources.
 *
 */
